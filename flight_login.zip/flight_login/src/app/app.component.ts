import { Component } from '@angular/core';
import { FormGroup, FormControl } from '../../node_modules/@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  private registerform:FormGroup;

  constructor() { }

  ngOnInit() {
    this.registerform=new FormGroup({
      username: new FormControl(""),
      password:new FormControl(""),
      email:new FormControl("")
    });
  }

  register(){
    console.log(this.registerform)
  }

}

