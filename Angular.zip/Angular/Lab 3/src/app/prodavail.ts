
export class Prodavail{
    prodTypeId:number;
    prodTypeName:string;
}