package com.capg.ui;

import java.util.Scanner;

import com.capg.DAO.FlightDAOImpl;
import com.capg.entities.FlightDetail;
import com.capg.entities.FlightUsers;
import com.capg.entities.UserRegister;

public class FlightReservation {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		FlightDAOImpl dao= new FlightDAOImpl();
		dao.addallFlight();
		int registrationNumber =0;
		int choice=0;
		while(choice!=6){
			System.out.println("Welcome to XYZ flight system");
			System.out.println("1. Registration ");
			System.out.println("2. View/Search fligth details ");
			System.out.println("3. ticket booking");
			System.out.println("4. cancelling the tickets");
			System.out.println("5. View tickets");
			System.out.println("6  exit");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter the Name ");
				String name=scanner.next();
				System.out.println("Enter the moblie number ");
				String moblienumber=scanner.next();
				System.out.println("Enter the City ");
				String City=scanner.next();
				registrationNumber++;
				boolean added = dao.saveUserDetail(new UserRegister(registrationNumber,name,moblienumber,City));
				if(added)
					System.out.println("added succesfully");
					System.out.println("==================================================================");
				break;
			case 2:
				System.out.println("Enter the flight details");
				System.out.println("==================================================================");
				System.out.println("Enter the flight id (flight Id should be between 1 to 4)");
				int flightId=scanner.nextInt();
				FlightDetail flight=dao.searchFlight(flightId);
				System.out.println(flight);
				break;
			case 3:
				System.out.println("Enter the source");
				String source= scanner.next();
				System.out.println("Enter the Destination");
				String destination= scanner.next();
				System.out.println("Enter the flight Id (flight Id should be between 1 to 4)");
				int flightId1=scanner.nextInt();
				System.out.println("Enter Name");
				String username= scanner.next();
				dao.bookFlight(new FlightUsers(source,destination,flightId1,username));
				break;	
			case 4:
				System.out.println("Enter the flight Id (flight Id should be between 1 to 4)");
				int flightId2=scanner.nextInt();
				dao.cancelFlight(flightId2);
				break;
			case 5:
				System.out.println("Enter the flight Id (flight Id should be between 1 to 4)");
				int flightId3=scanner.nextInt();
				FlightUsers result=dao.viewFlight(flightId3);
				System.out.println(result);
				break;
				
			case 6:
				choice=6;
				break;
				
			}
			
			
			
		}
		scanner.close();
		
		
	}

}
