package com.capg.entities;

public class FlightDetail {
	private String flight_Name;
	private int flight_Id;
	private double flight_Fare;
	private  String source_OF_Flight;
	private String destination_Of_Flight;
	
	public FlightDetail() {
		super();
	}

	public FlightDetail(String flightname, int flightId, double fare, String source, String destination) {
		super();
		this.flight_Name = flightname;
		this.flight_Id = flightId;
		this.flight_Fare = fare;
		this.source_OF_Flight = source;
		this.destination_Of_Flight = destination;
	}

	public String getFlightname() {
		return flight_Name;
	}

	public void setFlightname(String flightname) {
		this.flight_Name = flightname;
	}

	public int getFlightId() {
		return flight_Id;
	}

	public void setFlightId(int flightId) {
		this.flight_Id = flightId;
	}

	public double getFare() {
		return flight_Fare;
	}

	public void setFare(double fare) {
		this.flight_Fare = fare;
	}

	public String getSource() {
		return source_OF_Flight;
	}

	public void setSource(String source) {
		this.source_OF_Flight = source;
	}

	public String getDestination() {
		return destination_Of_Flight;
	}

	public void setDestination(String destination) {
		this.destination_Of_Flight = destination;
	}

	@Override
	public String toString() {
		return "Flight [flightname=" + flight_Name + ", flightId=" + flight_Id + ", fare=" + flight_Fare + ", source=" + source_OF_Flight
				+ ", destination=" + destination_Of_Flight + "]";
	}
	
	
	
	
	
	
	
}
