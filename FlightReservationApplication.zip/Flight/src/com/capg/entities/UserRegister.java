package com.capg.entities;

public class UserRegister {
	private int register_No;
	private String user_Name;
	private String user_moblieNumber;
	private String user_City;
	
	public UserRegister() {
		super();
	}

	public UserRegister(int registerNo, String name, String moblieNumber, String city) {
		super();
		this.register_No = registerNo;
		this.user_Name = name;
		this.user_moblieNumber = moblieNumber;
		this.user_City = city;
	}

	public int getRegisterNo() {
		return register_No;
	}

	public void setRegisterNo(int registerNo) {
		register_No = registerNo;
	}

	public String getName() {
		return user_Name;
	}

	public void setName(String name) {
		user_Name = name;
	}

	public String getMoblieNumber() {
		return user_moblieNumber;
	}

	public void setMoblieNumber(String moblieNumber) {
		this.user_moblieNumber = moblieNumber;
	}

	public String getCity() {
		return user_City;
	}

	public void setCity(String city) {
		this.user_City = city;
	}

	@Override
	public String toString() {
		return "UserRegister [RegisterNo=" + register_No + ", Name=" + user_Name + ", moblieNumber=" + user_moblieNumber
				+ ", city=" + user_City + "]";
	}
	

	
	

}
