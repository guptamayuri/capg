package com.capg.entities;

public class FlightUsers {
	String source_Of_Flight;
	String destination_Of_Flight;
	int fligth_Id;
	String userName;
	public FlightUsers(String source, String destination, int fligthId, String username) {
		super();
		this.source_Of_Flight = source;
		this.destination_Of_Flight = destination;
		this.fligth_Id = fligthId;
		this.userName = username;
	}
	public FlightUsers() {
		super();
	}
	public String getSource() {
		return source_Of_Flight;
	}
	public void setSource(String source) {
		this.source_Of_Flight = source;
	}
	public String getDestination() {
		return destination_Of_Flight;
	}
	public void setDestination(String destination) {
		this.destination_Of_Flight = destination;
	}
	public int getFligthId() {
		return fligth_Id;
	}
	public void setFligthId(int fligthId) {
		this.fligth_Id = fligthId;
	}
	public String getUsername() {
		return userName;
	}
	public void setUsername(String username) {
		this.userName = username;
	}
	@Override
	public String toString() {
		return "Flightuser [source=" + source_Of_Flight + ", destination=" + destination_Of_Flight + ", fligthId=" + fligth_Id
				+ ", username=" + userName + "]";
	}
	

}
