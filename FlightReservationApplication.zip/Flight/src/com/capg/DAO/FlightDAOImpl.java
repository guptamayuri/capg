package com.capg.DAO;

import java.util.ArrayList;
import java.util.List;

import com.capg.entities.FlightDetail;
import com.capg.entities.FlightUsers;
import com.capg.entities.UserRegister;

public class FlightDAOImpl implements FlightDao {
	List<UserRegister> list_Of_Users= new ArrayList<UserRegister>();
	List <FlightUsers> flight_Book_by_User=new ArrayList<>();
	List<FlightDetail> flight_List=new ArrayList<>();
	
	@Override
	public boolean saveUserDetail( UserRegister user){
		if(list_Of_Users.add(user))
			return true;
		else
			return false;
		
	}
	
	@Override
	public FlightDetail searchFlight(int flight_id) {
		FlightDetail flight = null;
		for(FlightDetail e: flight_List) {
			if(e.getFlightId()==flight_id) {
				flight=e;
			break;
			}
			
		}
		return flight;
		
		
	}
	
	@Override
	public void bookFlight(FlightUsers user) {
		flight_Book_by_User.add(user);
	}
	public void cancelFlight(int flightId){
		
		for(FlightUsers e: flight_Book_by_User) {
			if(e.getFligthId()==flightId) {
				flight_Book_by_User.remove(e);
			break;
			}
			
		}
		
		
		
	}
	
	@Override
	public FlightUsers viewFlight(int flightId) {
		FlightUsers flight = null;
		for(FlightUsers e: flight_Book_by_User) {
			if(e.getFligthId()==flightId) {
				flight=e;
			break;
			}
			
		}
		return flight;
		
	}
	
	@Override
	public void addallFlight(){
		
		flight_List.add(new FlightDetail("AirIndia",1,4200,"Hyderabad","Gwalior"));
		flight_List.add(new FlightDetail("Indigo",2,4500,"Pune","Chennai"));
		flight_List.add(new FlightDetail("SpiceJet",3,4000,"Bangalore","Hyderabad"));
		flight_List.add(new FlightDetail("Airlines",4,2500,"Goa","Gujarat"));
		flight_List.add(new FlightDetail("SpiceJet",5,3800,"Bangalore","Gwalior"));
		flight_List.add(new FlightDetail("Airlines",6,2500,"Delhi","Bhopal"));
		flight_List.add(new FlightDetail("AirIndia",7,4200,"Hyderabad","Kerala"));
		flight_List.add(new FlightDetail("Indigo",8,4500,"Pune","Delhi"));
	}

}
