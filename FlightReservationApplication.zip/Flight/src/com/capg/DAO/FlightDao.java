package com.capg.DAO;

import com.capg.entities.FlightDetail;
import com.capg.entities.FlightUsers;
import com.capg.entities.UserRegister;

public interface FlightDao {
	
	boolean saveUserDetail( UserRegister user);
	FlightDetail searchFlight(int flight_id);
	void bookFlight(FlightUsers user);
	FlightUsers viewFlight(int flightId);
	void addallFlight();

}
