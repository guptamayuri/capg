import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.css']
})
export class WelcomePageComponent implements OnInit {
  clickSearch = '';
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  forthFormGroup: FormGroup;
  fifthFormGroup: FormGroup;
  constructor(private _formBuilder: FormBuilder, private router:Router) { }

  ngOnInit() {
    this.firstFormGroup = new FormGroup({
      firstCtrl:new FormControl("")
    });
    this.secondFormGroup = new FormGroup({
      secondCtrl:new FormControl("")
    });
    this.thirdFormGroup = new FormGroup({
      thirdCtrl:new FormControl("")
    });
    this.forthFormGroup = new FormGroup({
      forthCtrl: new FormControl("")
    });
    this.fifthFormGroup = new FormGroup({
      fifthCtrl: new FormControl("")
    });
  }

  selection(){
    this.clickSearch = this.firstFormGroup.value.firstCtrl+' '+
                       this.secondFormGroup.value.secondCtrl+' '+
                       this.thirdFormGroup.value.thirdCtrl+' '+
                       this.forthFormGroup.value.forthCtrl+' '+
                       this.fifthFormGroup.value.fifthCtrl;
  }

  search(){
     this.router.navigate(['search'])
  }

}
