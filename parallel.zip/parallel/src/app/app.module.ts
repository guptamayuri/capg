import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatStepperModule, MatInputModule, MatButtonModule} from '@angular/material';
import { SignComponent } from './sign/sign.component';
import {MatTabsModule,MatSelectModule, MatNativeDateModule,MatDatepickerModule} from '@angular/material';
import { Routes,RouterModule } from '@angular/router';
import { SerchComponent } from './serch/serch.component';

const appRoutes:Routes =[
  {path: '', component:WelcomePageComponent},
  {path: 'sign', component: SignComponent},
  {path: 'search', component: SerchComponent}
 
]


@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    WelcomePageComponent,
    SignComponent,
    SerchComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    BrowserAnimationsModule,
    MatTabsModule,
    MatSelectModule,
    MatDatepickerModule,MatNativeDateModule,
    MatStepperModule, MatInputModule, MatButtonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
