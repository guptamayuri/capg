import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-sign',
  templateUrl: './sign.component.html',
  styleUrls: ['./sign.component.css']
})
export class SignComponent implements OnInit {
  private registerform:FormGroup;
  constructor() { }

  ngOnInit() {
    this.registerform=new FormGroup({
      username: new FormControl(""),
      password:new FormControl(""),
      email:new FormControl("")
    });
  }

  register(){
    console.log(this.registerform)
  }

}
